<?php include "textos.php"?>
<?php include "./inc/head.php" ?>


<div class="footer">
    <hr>
    <br>
    <p style="font-size: medium;">Gracias por visitarnos</p>
    
    <p><img src="./img/ubic.png" alt="ubicacion" width="10px">  Nuestra dirección: <?php echo $direc_principal?></p>
    <p><img src="./img/telef.png" alt="ubicacion" width="15px">  Llámenos al: <?php echo $tel_contacto?></p>
    <p><img src="./img/WApp.png" alt="ubicacion" width="15px">  Escríbanos al: <?php echo $wapp?></p>
    <br>
    <p>&copy 2023 <?php echo $nombre_principal?></p>
    <br>
</div>

