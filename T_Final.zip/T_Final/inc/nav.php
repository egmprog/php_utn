<?php include "./inc/textos.php" ?>
<div>
    <img src="./img/fachada02.jpg" alt="fachada" width="100%">
</div>
<div>
    <h2 class="titulo">Bienvenidos a la <?php echo $nombre_principal?></h2>
</div>
<nav class="nav1">    
    <div>
        <p><a href="home.php">Inicio</a> | <a href="menu.php">Menú del día</a> | <a href="reserva.php">Reserve una mesa</a></p>
    </div>
</nav>