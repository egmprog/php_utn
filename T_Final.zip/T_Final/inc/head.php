<?php include "./inc/textos.php" ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=, initial-scale=1.0">
<title><?php echo $nombre_principal ?></title>
<link rel="stylesheet" href="./inc/estilos.css">