<?php
$nombre_principal="Taberna dall' Nonno";
$tel_contacto="0800 0000 0000";
$direc_principal="Av del abuelo 1000, ciudad de Longevo";
$email_principal="correo@comercio.com";
$wapp="+549-11-0000-0000";