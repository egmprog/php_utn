<?php include "./inc/head.php" ?>
<?php include "./inc/nav.php" ?>
    <div class="cont1">
    <h3 class="p3">Pagina inicial</h3>
    <h3 class="p3">(contenido a desarrollar)</h3>
    </div>
<?php include "./inc/footer.php" ?>
