<link rel="stylesheet" href="./css/estilos.css">
<?php
include("./inc/nav.php");