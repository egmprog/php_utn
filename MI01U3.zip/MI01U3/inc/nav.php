<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de usuarios</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
<div class="nav1">
    <nav class="dropdown nav">
        <tr>
            <th>Usuarios</th>
        </tr>
        <ul >
            <li><a href="user_new.php">Añadir usuario</a></li>
            <li><a href="user_list.php">Lista de usuarios</a></li>
        </ul>
    </nav>
</div>
</body>
</html>
